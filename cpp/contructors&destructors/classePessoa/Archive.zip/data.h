#ifndef DATA_H
#define DATA_H
#include <string>

class data
{
private:
    int dia;
    int mes;
    int anos;
public:
    data(int dia, int mes, int ano);
    void print();
};





#endif